# DO NOT MODIFY THE CODE if your not sure what you are doing!/НЕ ИЗМЕНЯЙТЕ КОД, если вы не уверены, что делаете!!!!!!!!
# The code your seeing right now is open source and free to use and modify this file does not contain any malicious code or code that will break your PC. Please see the source code for your self./Код, который вы видите прямо сейчас, имеет открытый исходный код и беспощаден для использования и модификации, этот файл не содержит вредоносного кода или кода, который может сломать ваш компьютер. Пожалуйста, ознакомьтесь с исходным кодом самостоятельно.
# Credits: RandomBroLol from https://github.com/ 
import importlib.util
import subprocess
import sys
import aiohttp
import asyncio
import os
from colorama import Fore, Style, init

# Проверка и установка зависимостей
required = {'aiohttp', 'colorama'}
missing = []

for lib in required:
    if not importlib.util.find_spec(lib):
        missing.append(lib)

if missing:
    print(f"Installing dependencies: {', '.join(missing)}")
    subprocess.check_call([sys.executable, "-m", "pip", "install", *missing])

# Инициализация colorama после установки
init(autoreset=True)

# Локализации
lang_en = {
    "select_language": f"{Fore.RED}Select Language{Style.RESET_ALL}",
    "russian_option": f"1. Russian{Fore.BLUE}",
    "english_option": f"2. English{Fore.RED}",
    "input_prompt": f"{Fore.GREEN}Type >>> {Style.RESET_ALL}",
    "status_available": "Available",
    "status_taken": "Taken",
    "status_tagged": "Tagged",
    "status_unknown": "Unknown",
    "error_check": "Error: Unable to check username",
    "error_general": "Error",
    "press_exit": "Press Enter to exit...",
    "main_menu": f"{Fore.GREEN}Main Menu{Style.RESET_ALL}",
    "single_check": f"1. Check single username{Fore.YELLOW}",
    "batch_check": f"2. Check all from file{Fore.CYAN}",
    "enter_username": f"{Fore.MAGENTA}Enter username: {Style.RESET_ALL}",
    "processing_file": "\nProcessing usernames.txt file...",
    "invalid_choice": f"{Fore.RED}Invalid choice!{Style.RESET_ALL}",
    "dependencies_installed": f"{Fore.GREEN}All dependencies installed!{Style.RESET_ALL}"
}

lang_ru = {
    "select_language": f"{Fore.RED}Выберите язык{Style.RESET_ALL}",
    "russian_option": f"1. Русский{Fore.BLUE}",
    "english_option": f"2. Английский{Fore.RED}",
    "input_prompt": f"{Fore.GREEN}Введите >>> {Style.RESET_ALL}",
    "status_available": "Доступно",
    "status_taken": "Занято",
    "status_tagged": "Заблокировано",
    "status_unknown": "Неизвестно",
    "error_check": "Ошибка: Не удалось проверить имя",
    "error_general": "Ошибка",
    "press_exit": "Нажмите Enter для выхода...",
    "main_menu": f"{Fore.GREEN}Главное меню{Style.RESET_ALL}",
    "single_check": f"1. Проверить одно имя{Fore.YELLOW}",
    "batch_check": f"2. Проверить весь файл{Fore.CYAN}",
    "enter_username": f"{Fore.MAGENTA}Введите имя: {Style.RESET_ALL}",
    "processing_file": "\nОбрабатываю файл usernames.txt...",
    "invalid_choice": f"{Fore.RED}Неверный выбор!{Style.RESET_ALL}",
    "dependencies_installed": f"{Fore.GREEN}Все зависимости установлены!{Style.RESET_ALL}"
}

def select_language():
    print(f"\n{Fore.YELLOW}Язык/Language{Style.RESET_ALL}")
    print(f"{Fore.CYAN}1. Русский{Style.RESET_ALL}")
    print(f"{Fore.MAGENTA}2. English{Style.RESET_ALL}")
    choice = input(f"{Fore.GREEN}Выбор/Choice >>> {Style.RESET_ALL}")
    return lang_ru if choice == "1" else lang_en

def main_menu(lang):
    print(f"\n{lang['main_menu']}")
    print(lang['single_check'])
    print(lang['batch_check'])
    return input(lang['input_prompt'])

async def check_username(session, username, lang):
    url = f"https://auth.roblox.com/v1/usernames/validate?request.username={username}&request.birthday=2000-01-01"
    try:
        async with session.get(url) as response:
            if response.status == 200:
                data = await response.json()
                codes = {
                    0: f"{Fore.GREEN}{lang['status_available']}",
                    1: f"{Fore.RED}{lang['status_taken']}",
                    2: f"{Fore.YELLOW}{lang['status_tagged']}"
                }
                return codes.get(data["code"], f"{Fore.BLUE}{lang['status_unknown']}")
            return f"{Fore.RED}{lang['error_check']} (HTTP {response.status})"
    except Exception as e:
        return f"{Fore.RED}{lang['error_general']}: {e}"

def read_usernames(file_path):
    try:
        with open(file_path, "r") as file:
            return [line.strip() for line in file if line.strip()]
    except FileNotFoundError:
        print(f"{Fore.RED}File {file_path} not found!")
        return []

async def process_usernames(session, usernames, lang, batch_size=50):
    for i in range(0, len(usernames), batch_size):
        batch = usernames[i:i + batch_size]
        tasks = [check_username(session, name, lang) for name in batch]
        results = await asyncio.gather(*tasks)
        
        for name, result in zip(batch, results):
            print(f"Username: {Fore.CYAN}{name}{Style.RESET_ALL} - Status: {result}")
        await asyncio.sleep(1)

async def check_single_username(session, lang):
    username = input(lang['enter_username'])
    result = await check_username(session, username, lang)
    print(f"\n{Fore.CYAN}{username}{Style.RESET_ALL} - {result}")

async def main(lang):
    choice = main_menu(lang)
    
    connector = aiohttp.TCPConnector(
        resolver=aiohttp.AsyncResolver(),
        limit_per_host=10,
        ssl=False
    )
    
    async with aiohttp.ClientSession(connector=connector) as session:
        if choice == "1":
            await check_single_username(session, lang)
        elif choice == "2":
            print(lang['processing_file'])
            if usernames := read_usernames("usernames.txt"):
                await process_usernames(session, usernames, lang)
        else:
            print(lang['invalid_choice'])

    input(f"\n{Fore.YELLOW}{lang['press_exit']}{Style.RESET_ALL}")

if __name__ == "__main__":
    if os.name == "nt":
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    
    lang = select_language()
    print(f"\n{lang['dependencies_installed']}")
    asyncio.run(main(lang))