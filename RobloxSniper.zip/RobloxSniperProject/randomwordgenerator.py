# DO NOT MODIFY THE CODE if your not sure what you are doing!/НЕ ИЗМЕНЯЙТЕ КОД, если вы не уверены, что делаете!!!!!!!!
# The code your seeing right now is open source and free to use and modify this file does not contain any malicious code or code that will break your PC. Please see the source code for your self./Код, который вы видите прямо сейчас, имеет открытый исходный код и беспощаден для использования и модификации, этот файл не содержит вредоносного кода или кода, который может сломать ваш компьютер. Пожалуйста, ознакомьтесь с исходным кодом самостоятельно.
# Credits: RandomBroLol from https://github.com/randombrolol
import random
import string

# Color codes
GREEN = '\033[92m'
YELLOW = '\033[93m'
RED = '\033[91m'
RESET = '\033[0m'

def get_valid_number(prompt, min_val, max_val):
    print(f"{YELLOW}{prompt} ({min_val}-{max_val}){RESET}")
    while True:
        try:
            value = int(input(f"{GREEN}>>> {RESET}"))
            if min_val <= value <= max_val:
                return value
            print(f"{RED}Error: Please enter between {min_val}-{max_val}{RESET}")
        except ValueError:
            print(f"{RED}Error: Please enter a valid number{RESET}")

def generate_random_word(length):
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(length))

def main():
    print(f"{YELLOW}=== Random String Generator ==={RESET}")
    
    # Get number of words
    num_words = get_valid_number("\nHow many words to generate?", 1, 1000)
    
    # Get word length
    word_length = get_valid_number("\nHow long should each word be?", 8, 21)
    
    # Generate words
    words = [generate_random_word(word_length) for _ in range(num_words)]
    
    # Save to file
    filename = "random_strings.txt"
    try:
        with open(filename, 'w') as file:
            file.write('\n'.join(words))
        print(f"{YELLOW}\nSuccessfully generated {GREEN}{num_words}{YELLOW} x {GREEN}{word_length}{YELLOW}-character strings!")
        print(f"Saved to: {GREEN}{filename}{RESET}")
    except Exception as e:
        print(f"{RED}Error saving file: {e}{RESET}")

if __name__ == "__main__":
    main()